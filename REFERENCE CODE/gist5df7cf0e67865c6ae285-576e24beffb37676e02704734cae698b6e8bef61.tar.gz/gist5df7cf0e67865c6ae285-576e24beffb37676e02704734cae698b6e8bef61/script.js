var myString = "sebastian";
//string

var myNum = 10;
// int

var myDecimal = 10.332432;
// float

var myArray = [];
myArrray = ['hello', myString, 20, 'cool', myDecimal];
// Array
myArray[0]
// hello
myArray[1]
// sebastian
myArray[4]
// 10.332432

var profObject = {
  name:'sebastian',
  height: 5.9,
  website: 'www.the212.co',
  age: 25
};

profObject.name
// sebastian

profObject.age
// 25