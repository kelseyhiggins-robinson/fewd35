// create a "total" variable that will store our total count
// set total to zero (value start)
var total = 0;

//create click listeners for the buttons
$('#add5').click(
  function() {
 	 total = total + 5;
  	renderResult();
	}
);
//anonymous function

$('#sub1').click(function() {
 	 total = total - 1;
  	renderResult();
});

$('#zero').click(function() {
 	 total = 0;
  	renderResult();
});

$('#add10').click(add10);

function add10() {
  total = total + 10;
  renderResult();
}

function renderResult() {
  $('#result').html(total);
}
// declared function

//add or subtract specific value from total

//render new total