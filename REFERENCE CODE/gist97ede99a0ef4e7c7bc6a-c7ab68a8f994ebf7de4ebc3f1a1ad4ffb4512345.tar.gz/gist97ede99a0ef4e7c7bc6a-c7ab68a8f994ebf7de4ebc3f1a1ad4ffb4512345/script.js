//click listener for "compare btn"
$('#submit').click(compare);

function compare() {
 	//create 2 variables (a & b)
	var a, b;
  // store input values into specific variable
	a = $('#a').val();
  b = $('#b').val();
  
  a = parseFloat(a);
  b = parseFloat(b);
  
  // compare a & b
  if(a > b) {
    $('#comparison').html('>');
  }else if(a < b) {
    $('#comparison').html('<');
  } else if(a == b) {
    $('#comparison').html('=');
  }

  // based on condition, render <, > or = inside the "comparison" element 
}