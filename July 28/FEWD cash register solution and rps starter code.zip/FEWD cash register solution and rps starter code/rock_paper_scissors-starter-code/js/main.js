// create humanTotal and compTotal variables
// set them to 0

// button click listeners that detect click evnet... and call playGame
//function, and pass the player's choice...

// create playGame function
// function playGame(humanPlay);

	//assign random computer play to variable
	// use array for comp options... 
	// var compOptions = ["rock", "paper", "scissor"];
	// var compPlay = compOptions[1];

	// conditional (if, else if, else if, else if... else )
	// if humanPlay == 'rock' && compPlay == 'rock'...
	// else if humanPlay == 'rock' && compPLay == 'paper'
	/// etc...

	//based on condition add to human or comp comp compTotal

	// render new result

	//etc...